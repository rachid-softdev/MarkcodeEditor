import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { Download, Upload, Palette, Square, Circle, Hexagon, Crown, Check, X } from 'lucide-react';
import html2canvas from 'html2canvas';

interface QROptions {
  url: string;
  foregroundColor: string;
  backgroundColor: string;
  logo: string | null;
  pixelStyle: 'square' | 'circle' | 'hexagon';
}

interface QRGeneratorProps {
  onPremiumClick: () => void;
}

const QRGenerator: React.FC<QRGeneratorProps> = ({ onPremiumClick }) => {
  const [options, setOptions] = useState<QROptions>({
    url: '',
    foregroundColor: '#000000',
    backgroundColor: '#ffffff',
    logo: null,
    pixelStyle: 'square'
  });
  
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCustomization, setShowCustomization] = useState(false);
  const qrCanvasRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateQR = async () => {
    if (!options.url.trim()) return;
    
    setIsGenerating(true);
    try {
      const qrOptions = {
        width: 300,
        margin: 2,
        color: {
          dark: options.foregroundColor,
          light: options.backgroundColor
        }
      };
      
      const dataUrl = await QRCode.toDataURL(options.url, qrOptions);
      setQrDataUrl(dataUrl);
      setShowCustomization(true);
    } catch (error) {
      console.error('Erreur génération QR:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setOptions(prev => ({ ...prev, logo: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const downloadFreeVersion = async () => {
    if (!qrCanvasRef.current) return;
    
    try {
      const canvas = await html2canvas(qrCanvasRef.current, {
        width: 400,
        height: 450,
        scale: 1
      });
      
      const link = document.createElement('a');
      link.download = 'qr-code-free.png';
      link.href = canvas.toDataURL();
      link.click();
    } catch (error) {
      console.error('Erreur téléchargement:', error);
    }
  };

  useEffect(() => {
    if (options.url && showCustomization) {
      const debounce = setTimeout(generateQR, 300);
      return () => clearTimeout(debounce);
    }
  }, [options.foregroundColor, options.backgroundColor, options.pixelStyle]);

  const pixelStyleOptions = [
    { value: 'square', icon: Square, label: 'Carrés' },
    { value: 'circle', icon: Circle, label: 'Cercles' },
    { value: 'hexagon', icon: Hexagon, label: 'Hexagones' }
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">
          Générateur de QR Codes
          <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Augmentés</span>
        </h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Créez des QR codes personnalisés et stylisés en quelques secondes
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-12 items-start">
        {/* Section Génération */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Entrez votre URL</h3>
            
            <div className="space-y-4">
              <div>
                <input
                  type="url"
                  value={options.url}
                  onChange={(e) => setOptions(prev => ({ ...prev, url: e.target.value }))}
                  placeholder="https://example.com"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-lg"
                />
              </div>
              
              <button
                onClick={generateQR}
                disabled={!options.url.trim() || isGenerating}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                {isGenerating ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Génération...</span>
                  </div>
                ) : (
                  'Générer QR Code'
                )}
              </button>
            </div>
          </div>

          {/* Options de Personnalisation */}
          {showCustomization && (
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 animate-fade-in">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Personnalisation</h3>
              
              <div className="space-y-6">
                {/* Couleurs */}
                <div>
                  <h4 className="flex items-center font-medium text-gray-900 mb-3">
                    <Palette className="w-5 h-5 mr-2 text-blue-600" />
                    Couleurs
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-600 mb-2">QR Code</label>
                      <div className="flex items-center space-x-3">
                        <input
                          type="color"
                          value={options.foregroundColor}
                          onChange={(e) => setOptions(prev => ({ ...prev, foregroundColor: e.target.value }))}
                          className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
                        />
                        <span className="text-sm font-mono text-gray-700">{options.foregroundColor}</span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-2">Arrière-plan</label>
                      <div className="flex items-center space-x-3">
                        <input
                          type="color"
                          value={options.backgroundColor}
                          onChange={(e) => setOptions(prev => ({ ...prev, backgroundColor: e.target.value }))}
                          className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
                        />
                        <span className="text-sm font-mono text-gray-700">{options.backgroundColor}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Logo */}
                <div>
                  <h4 className="flex items-center font-medium text-gray-900 mb-3">
                    <Upload className="w-5 h-5 mr-2 text-blue-600" />
                    Logo au centre
                  </h4>
                  <div className="flex items-center space-x-4">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {options.logo ? 'Changer logo' : 'Ajouter logo'}
                    </button>
                    {options.logo && (
                      <button
                        onClick={() => setOptions(prev => ({ ...prev, logo: null }))}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Formes des pixels */}
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Style des pixels</h4>
                  <div className="grid grid-cols-3 gap-3">
                    {pixelStyleOptions.map(({ value, icon: Icon, label }) => (
                      <button
                        key={value}
                        onClick={() => setOptions(prev => ({ ...prev, pixelStyle: value as any }))}
                        className={`flex flex-col items-center p-4 rounded-lg border-2 transition-all ${
                          options.pixelStyle === value
                            ? 'border-blue-600 bg-blue-50 text-blue-700'
                            : 'border-gray-200 hover:border-gray-300 text-gray-600'
                        }`}
                      >
                        <Icon className="w-6 h-6 mb-2" />
                        <span className="text-sm font-medium">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Section Prévisualisation et Téléchargement */}
        {qrDataUrl && (
          <div className="space-y-6">
            {/* Prévisualisation */}
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 animate-fade-in">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Prévisualisation</h3>
              
              <div ref={qrCanvasRef} className="relative bg-gray-50 rounded-xl p-8 flex flex-col items-center">
                <div className="relative">
                  <img 
                    src={qrDataUrl} 
                    alt="QR Code"
                    className="w-64 h-64 rounded-lg"
                    style={{ imageRendering: 'pixelated' }}
                  />
                  
                  {/* Logo overlay */}
                  {options.logo && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <img 
                        src={options.logo}
                        alt="Logo"
                        className="w-16 h-16 rounded-lg shadow-lg bg-white p-1"
                      />
                    </div>
                  )}
                </div>
                
                {/* Watermark */}
                <div className="mt-4 text-sm text-gray-400 font-medium bg-white/80 px-3 py-1 rounded-full">
                  Free Version
                </div>
              </div>
            </div>

            {/* Options de téléchargement */}
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              <div className="p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-6">Téléchargement</h3>
                
                <div className="space-y-4">
                  {/* Version gratuite */}
                  <div className="border border-gray-200 rounded-xl p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">Version Gratuite</h4>
                        <p className="text-sm text-gray-600 mt-1">PNG 400x400px • Avec watermark</p>
                      </div>
                      <button
                        onClick={downloadFreeVersion}
                        className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Télécharger
                      </button>
                    </div>
                  </div>

                  {/* Version premium */}
                  <div className="border border-orange-200 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center">
                          <Crown className="w-5 h-5 text-orange-600 mr-2" />
                          <h4 className="font-semibold text-gray-900">Version Premium</h4>
                        </div>
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center text-sm text-gray-700">
                            <Check className="w-4 h-4 text-green-600 mr-2" />
                            HD 3000x3000px
                          </div>
                          <div className="flex items-center text-sm text-gray-700">
                            <Check className="w-4 h-4 text-green-600 mr-2" />
                            Export SVG vectoriel
                          </div>
                          <div className="flex items-center text-sm text-gray-700">
                            <Check className="w-4 h-4 text-green-600 mr-2" />
                            Sans watermark
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-orange-600 mb-2">2,99€</div>
                        <button
                          onClick={onPremiumClick}
                          className="bg-gradient-to-r from-orange-600 to-red-600 text-white font-semibold px-6 py-2 rounded-lg hover:from-orange-700 hover:to-red-700 transition-all transform hover:scale-105"
                        >
                          Obtenir Premium
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QRGenerator;