import React from 'react';
import { Check, X, Crown, Zap } from 'lucide-react';

interface PricingProps {
  onPremiumClick: () => void;
}

const Pricing: React.FC<PricingProps> = ({ onPremiumClick }) => {
  const plans = [
    {
      name: 'Gratuit',
      price: '0€',
      description: 'Pour tester et découvrir',
      icon: Zap,
      features: [
        { text: 'QR codes illimités', included: true },
        { text: 'Personnalisation basique', included: true },
        { text: 'Export PNG 400x400px', included: true },
        { text: 'Avec watermark', included: true, note: true },
        { text: 'Export HD 3000x3000px', included: false },
        { text: 'Export SVG vectoriel', included: false },
        { text: 'Sans watermark', included: false }
      ],
      buttonText: 'Commencer gratuitement',
      buttonClass: 'bg-gray-600 hover:bg-gray-700',
      popular: false
    },
    {
      name: 'Premium',
      price: '2,99€',
      priceNote: 'par QR code',
      description: 'Pour un usage professionnel',
      icon: Crown,
      features: [
        { text: 'Tout du plan gratuit', included: true },
        { text: 'Export HD 3000x3000px', included: true },
        { text: 'Export SVG vectoriel', included: true },
        { text: 'Export PDF vectoriel', included: true },
        { text: 'Sans watermark', included: true },
        { text: 'Modèles stylés premium', included: true },
        { text: 'Support prioritaire', included: true }
      ],
      buttonText: 'Obtenir Premium',
      buttonClass: 'bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700',
      popular: true
    }
  ];

  return (
    <div className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Tarifs simples et transparents
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Commencez gratuitement et passez au premium quand vous en avez besoin
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <div
                key={plan.name}
                className={`relative bg-white rounded-2xl shadow-lg border-2 transition-all hover:shadow-xl ${
                  plan.popular 
                    ? 'border-orange-200 ring-4 ring-orange-100' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                      Le plus populaire
                    </div>
                  </div>
                )}

                <div className="p-8">
                  <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-4">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                    <div className="mb-2">
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                      {plan.priceNote && (
                        <span className="text-sm text-gray-500 ml-2">{plan.priceNote}</span>
                      )}
                    </div>
                    <p className="text-gray-600">{plan.description}</p>
                  </div>

                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        {feature.included ? (
                          <Check className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400 mr-3 flex-shrink-0" />
                        )}
                        <span className={`text-sm ${
                          feature.included ? 'text-gray-900' : 'text-gray-500'
                        } ${feature.note ? 'italic' : ''}`}>
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={plan.name === 'Premium' ? onPremiumClick : undefined}
                    className={`w-full text-white font-semibold py-3 px-6 rounded-xl transition-all transform hover:scale-[1.02] ${plan.buttonClass}`}
                  >
                    {plan.buttonText}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pack crédits section */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-100 max-w-2xl mx-auto">
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">
              Besoin de plusieurs QR codes ?
            </h3>
            <p className="text-gray-600 mb-6">
              Économisez avec nos packs de crédits pour un usage intensif
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <div className="text-lg font-semibold text-gray-900">Pack 10 QR</div>
                <div className="text-2xl font-bold text-blue-600">24,99€</div>
                <div className="text-sm text-gray-500">2,49€/QR (-16%)</div>
              </div>
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <div className="text-lg font-semibold text-gray-900">Pack 50 QR</div>
                <div className="text-2xl font-bold text-purple-600">99,99€</div>
                <div className="text-sm text-gray-500">1,99€/QR (-33%)</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;