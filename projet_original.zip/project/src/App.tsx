import React, { useState } from 'react';
import Hero from './components/Hero';
import QRGenerator from './components/QRGenerator';
import Pricing from './components/Pricing';
import StripeCheckout from './components/StripeCheckout';

function App() {
  const [showCheckout, setShowCheckout] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <Hero />
      
      {/* QR Generator Section */}
      <div id="generator" className="bg-white">
        <QRGenerator onPremiumClick={() => setShowCheckout(true)} />
      </div>
      
      {/* Pricing Section */}
      <Pricing onPremiumClick={() => setShowCheckout(true)} />
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">QR Codes Augmentés</h3>
            <p className="text-gray-400 mb-6">
              La solution moderne pour créer des QR codes professionnels
            </p>
            <div className="flex justify-center space-x-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Conditions d'utilisation</a>
              <a href="#" className="hover:text-white transition-colors">Politique de confidentialité</a>
              <a href="#" className="hover:text-white transition-colors">Support</a>
            </div>
            <div className="mt-8 pt-8 border-t border-gray-800 text-sm text-gray-500">
              © 2025 QR Codes Augmentés. Tous droits réservés.
            </div>
          </div>
        </div>
      </footer>

      {/* Stripe Checkout Modal */}
      <StripeCheckout 
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
      />
    </div>
  );
}

export default App;