import React from 'react';
import { QrCode, Sparkles, Download, Palette } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToGenerator = () => {
    const element = document.getElementById('generator');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-32 w-80 h-80 rounded-full bg-gradient-to-br from-blue-400/20 to-purple-600/20 blur-3xl"></div>
        <div className="absolute -bottom-40 -left-32 w-80 h-80 rounded-full bg-gradient-to-tr from-purple-400/20 to-pink-600/20 blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 py-24">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200 rounded-full text-sm font-medium text-blue-800 mb-8">
            <Sparkles className="w-4 h-4 mr-2" />
            QR Codes Nouvelle Génération
          </div>

          {/* Titre principal */}
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            QR Codes
            <br />
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Augmentés
            </span>
          </h1>

          {/* Sous-titre */}
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Créez des QR codes personnalisés, stylisés et professionnels avec logo, 
            couleurs personnalisées et exports haute définition
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={scrollToGenerator}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold px-8 py-4 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <QrCode className="w-5 h-5 inline mr-2" />
              Créer un QR Code
            </button>
            <button
              onClick={scrollToGenerator}
              className="bg-white text-gray-700 font-semibold px-8 py-4 rounded-xl hover:bg-gray-50 transition-all border border-gray-200 shadow-lg hover:shadow-xl"
            >
              Voir un exemple
            </button>
          </div>

          {/* Features preview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center p-6 bg-white/60 backdrop-blur rounded-2xl border border-white/20 shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4">
                <Palette className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Personnalisation</h3>
              <p className="text-sm text-gray-600 text-center">
                Couleurs, logos et formes personnalisées pour votre marque
              </p>
            </div>

            <div className="flex flex-col items-center p-6 bg-white/60 backdrop-blur rounded-2xl border border-white/20 shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                <Download className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Export HD</h3>
              <p className="text-sm text-gray-600 text-center">
                PNG haute définition et SVG vectoriel pour tous usages
              </p>
            </div>

            <div className="flex flex-col items-center p-6 bg-white/60 backdrop-blur rounded-2xl border border-white/20 shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl flex items-center justify-center mb-4">
                <QrCode className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Instantané</h3>
              <p className="text-sm text-gray-600 text-center">
                Génération en temps réel avec prévisualisation immédiate
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;