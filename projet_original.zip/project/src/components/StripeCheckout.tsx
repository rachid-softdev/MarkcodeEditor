import React, { useState } from 'react';
import { X, CreditCard, Shield, Lock } from 'lucide-react';

interface StripeCheckoutProps {
  isOpen: boolean;
  onClose: () => void;
  qrData?: {
    url: string;
    options: any;
  };
}

const StripeCheckout: React.FC<StripeCheckoutProps> = ({ isOpen, onClose, qrData }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  
  if (!isOpen) return null;

  const handlePayment = async () => {
    setIsLoading(true);
    
    // Simulation du processus de paiement Stripe
    // Dans un vrai projet, vous appelleriez l'API Stripe ici
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Redirection vers page de succès
    alert('Paiement réussi ! Redirection vers la page de téléchargement...');
    setIsLoading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-gray-900">Paiement sécurisé</h3>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Récapitulatif commande */}
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl p-6 mb-6 border border-orange-100">
            <h4 className="font-semibold text-gray-900 mb-3">Votre commande</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">QR Code Premium</span>
                <span className="font-medium">2,99€</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">TVA (20%)</span>
                <span className="font-medium">0,60€</span>
              </div>
              <div className="border-t border-orange-200 pt-2 mt-2">
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span className="text-orange-600">3,59€</span>
                </div>
              </div>
            </div>
          </div>

          {/* Formulaire */}
          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adresse email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Informations de paiement
              </label>
              <div className="border border-gray-300 rounded-lg p-4 bg-gray-50">
                <div className="flex items-center text-sm text-gray-600">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Paiement sécurisé via Stripe
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Cliquez sur "Payer maintenant" pour être redirigé vers le formulaire de paiement sécurisé Stripe.
                </p>
              </div>
            </div>
          </div>

          {/* Sécurité */}
          <div className="flex items-center justify-center text-sm text-gray-500 mb-6">
            <Shield className="w-4 h-4 mr-2" />
            <span>Paiement sécurisé SSL</span>
            <Lock className="w-4 h-4 ml-2" />
          </div>

          {/* Boutons */}
          <div className="space-y-3">
            <button
              onClick={handlePayment}
              disabled={!email || isLoading}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-orange-700 hover:to-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Traitement...
                </div>
              ) : (
                'Payer maintenant - 3,59€'
              )}
            </button>
            <button
              onClick={onClose}
              className="w-full text-gray-600 font-medium py-3 px-6 rounded-xl hover:bg-gray-100 transition-colors"
            >
              Annuler
            </button>
          </div>

          {/* Garanties */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-2 gap-4 text-xs text-gray-500">
              <div className="flex items-center">
                <Shield className="w-3 h-3 mr-1" />
                Remboursé 30j
              </div>
              <div className="flex items-center">
                <Lock className="w-3 h-3 mr-1" />
                Paiement sécurisé
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StripeCheckout;